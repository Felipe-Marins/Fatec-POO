
import fatec.poo.model.Aluno;
import fatec.poo.model.Professor;
import java.text.DecimalFormat;

/**
 *
 * @author Dimas
 */
public class Aplic {
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        //instanciação do objeto da classe Aluno
        Aluno objAlu = new Aluno(1010, "Carlos Silveira", "15/03/1978");
     
        //instanciação do objeto da classe Professor
        Professor objProf = new Professor(190, "Pedro Araujo", "23/09/1964");
        
        //passagem de mensagens
        objAlu.setMensalidade(1500);
        System.out.println("Registro Escolar: " + objAlu.getRegEscolar());
        System.out.println("Nome : " + objAlu.getNome());
        System.out.println("Data Nascimento: " + objAlu.getDataNascimento());
        System.out.println("Mensalidade: " + 
                            df.format(objAlu.getMensalidade()));    
    
        objProf.setSalario(2350);
        System.out.println("\nRegistro Funcional: " + objProf.getRegFuncional());
        System.out.println("Nome : " + objProf.getNome());
        System.out.println("Data Nascimento: " + objProf.getDataNascimento());
        System.out.println("Salário: " + df.format(objProf.getSalario()));
    }    
}
