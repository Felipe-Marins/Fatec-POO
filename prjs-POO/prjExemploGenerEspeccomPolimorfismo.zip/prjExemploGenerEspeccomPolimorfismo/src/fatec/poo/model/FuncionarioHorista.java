package fatec.poo.model;

/**
 *
 * @author Fatec
 */
public class FuncionarioHorista extends Funcionario{
    private int qtdeHorTrab;
    private double valHorTrab;

    public FuncionarioHorista(int registro, String nome, String dtAdmissao, double valHorTrab) {
        super(registro, nome, dtAdmissao);
        this.valHorTrab = valHorTrab;
    }

    public void setQtdeHorTrab(int qtdeHorTrab) {
        this.qtdeHorTrab = qtdeHorTrab;
    }
        
    @Override
    public double calcSalBruto() {
        return(qtdeHorTrab * valHorTrab);
    }
    
}
